# Formatless R64 qualification: memory backlog

The 4704-case r1 run encountered VM ENOMEM followed by VM timeouts; retained
kernel logs contain no matching native retirement timeout. The three implicated
cases pass after reboot. The second full run was stopped at 509184 KiB available;
Shmem rose from 929968 KiB to 13237408 KiB.
Memory returned after the workload stopped. No result is accepted as a full pass.

The exact frozen 1000-case prefix then passed twice, 392 Pass / 608 NS,
in 32.013 and 30.501 seconds, with 12 workers and one case per process.
Evidence: 20260916T152922066145Z-dx-image64-formatless-memory-r1 and
20260916T153212995415Z-dx-image64-formatless-memory-r2.
Shmem reached 8133 and 8249 MiB despite only about 12 current CTS clients.
The latter run repeatedly sampled a kernel worker inside
`delayed_fput -> __fput -> shmem_evict_inode -> shmem_undo_range` while the
GPU completion worker allocated the next Compute backing. This supports a
backlog of private shmem files whose GEM references are already released.

Candidate: Rust shmem free callback retains a file reference across
`drm_gem_shmem_release`, then consumes it using `__fput_sync`. The ordinary
release cannot queue final fput because the retained reference remains.
Imported buffers have no private shmem file. Final DMA mappings/page pins and
reservation locks are released before synchronous file eviction. No global
flush of unrelated files, firmware retirement rule, or cache retention change.

Built module SHA256 a5affc7dcc90cd7b29ae230ff7324fbd8712d9aadab7419882038e16b95a4f86.
Activated via guarded reboot 20260916-shmem-sync-reclaim-r1-reboot.
The same 1000-case prefix passes after the patch: 392 Pass / 608 NS,
35.576 seconds, peak64.75C. Sampled Shmem peaks at 1701 MiB (before8249 MiB),
minimum available11009 MiB. Samples:768,1510,1701,1463,1640,1640,1571,938 MiB.
Evidence:20260916T154230554149Z-dx-image64-formatless-memory-fixed-r1.
Full4704-case run image-formatless-r3 is now active; further regression pending.
