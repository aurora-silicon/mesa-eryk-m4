import hashlib,shutil,subprocess,sys
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
shutil.copyfile(__file__,out/'runner.py')
binary='/root/vk-buffer-oracle-formatless-r1'
(out/'binaries.sha256').write_text(''.join(hashlib.sha256(Path(p).read_bytes()).hexdigest()+'  '+p+'\n' for p in [binary,'/opt/asahi-m4-port/lib/libvulkan_asahi.so']))
subprocess.run(['python3','/root/run-image-final-oracles.py',str(out/'atomic64')],check=True,timeout=220)
subprocess.run(['python3','/root/run-m4-gl.py','python3','/root/formatless-oracles-r1/run.py',str(out/'formatless'),binary],check=True,timeout=90)
print('PASS: 108 independent atomic64 formatless alias and scratch configurations',flush=True)
