#!/usr/bin/env python3
import json,math,os,struct,sys,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
failed=0
for c in json.loads((r/'cases.json').read_text()):
 name=c['name'];print('MINMAX_CASE:',name,flush=True)
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run([sys.argv[2],str(r/(name+'.spv')),str(r/(name+'-input.bin')),str(r/(name+'.bin')),'4',str(out/(name+'.bin'))],env=dict(os.environ,**c['env']),timeout=30,stdout=log,stderr=subprocess.STDOUT)
 good=p.returncode==0
 if c['mode']==0 and p.returncode in (0,1) and (out/(name+'.bin')).exists():
  actual=(out/(name+'.bin')).read_bytes();expected=(r/(name+'.bin')).read_bytes()
  good=len(actual)==len(expected) and actual[:16384]==expected[:16384] and actual[20480:]==expected[20480:]
  worst=0.
  if good:
   for offset in range(16384,20480,4):
    a=struct.unpack_from('<f',actual,offset)[0];e=struct.unpack_from('<f',expected,offset)[0]
    worst=max(worst,abs(a-e) if math.isfinite(a) else float('inf'))
   good=worst<=.001
  print(('PASS' if good else 'FAIL')+': weighted numeric check '+name+' max_error='+str(worst),flush=True)
 if c['mode']!=0: print(('PASS' if good else 'FAIL')+': exact minmax '+name,flush=True)
 failed+=not good
print(('FAIL' if failed else 'PASS')+': minmax sampler oracles',flush=True)
sys.exit(bool(failed))
