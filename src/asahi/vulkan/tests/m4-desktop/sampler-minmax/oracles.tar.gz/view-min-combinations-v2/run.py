#!/usr/bin/env python3
import json,math,os,struct,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
failed=0
for c in json.loads((r/'cases.json').read_text()):
 n=c['name'];print('VIEW_MIN_CASE:',n,flush=True)
 with (out/(n+'.log')).open('w') as log:
  p=subprocess.run([sys.argv[2],str(r/(n+'.spv')),str(r/'input.bin'),str(r/(n+'.bin')),'4',str(out/(n+'.bin'))],env=dict(os.environ,**c['env']),timeout=30,stdout=log,stderr=subprocess.STDOUT)
 actual=(out/(n+'.bin')).read_bytes() if (out/(n+'.bin')).exists() else b''
 expected=(r/(n+'.bin')).read_bytes()
 good=p.returncode in (0,1) and len(actual)==len(expected) and actual[:16384]==expected[:16384] and actual[20480:]==expected[20480:]
 worst=0.
 if good:
  for offset in range(16384,20480,4):
   a=struct.unpack_from('<f',actual,offset)[0];e=struct.unpack_from('<f',expected,offset)[0]
   error=abs(a-e) if math.isfinite(a) else float('inf')
   worst=max(worst,error)
  # 2/256 LOD at 16 units per level; covers derivative/LOD precision only.
  good=worst<=.125
 print(('PASS' if good else 'FAIL')+': view minimum numeric check '+n+' max_error='+str(worst),flush=True)
 failed+=not good
print(('FAIL' if failed else 'PASS')+': view minimum sampler combinations',flush=True)
sys.exit(bool(failed))
