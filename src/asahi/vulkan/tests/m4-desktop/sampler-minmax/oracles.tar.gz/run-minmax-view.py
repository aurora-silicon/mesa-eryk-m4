import os,subprocess,sys
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
binary='/root/dx-texel-cases/vk-buffer-oracle-minmax'
failed=0
for name,path in [('minmax','/root/minmax-oracles-v5'),('view','/root/dx-view-min-combinations-v2'),('weighted','/root/weighted-view-oracles-v2'),('shadow','/root/weighted-shadow-oracles')]:
 print('ORACLE_SUITE:',name,flush=True)
 p=subprocess.run(['python3',path+'/run.py',str(out/name),binary],timeout=65)
 failed+=p.returncode!=0
for mode in [0,1]:
 for reduction in [1,2]:
  for nearest in [False,True]:
   env=dict(os.environ,M4_QUERY_REDUCTION=str(reduction),M4_QUERY_BIAS='.75',M4_QUERY_MIN='1.25',M4_QUERY_MAX='3.25')
   if nearest:env['M4_QUERY_NEAREST']='1'
   p=subprocess.run(['/root/dx-query-minmax',str(mode)],env=env,timeout=20)
   failed+=p.returncode!=0
print(('FAIL' if failed else 'PASS')+': combined minmax and view minimum oracles',flush=True)
sys.exit(bool(failed))
