#include <metal_stdlib>
using namespace metal;
kernel void probe(texturecube_array<float, access::sample> a [[texture(0)]],
                  texturecube_array<float, access::sample> b [[texture(1)]],
                  sampler s [[sampler(0)]],
                  device float4 *out [[buffer(0)]],
                  constant float4 &p [[buffer(1)]],
                  uint i [[thread_position_in_grid]]) {
  float4 x = a.sample(s,p.xyz,i&1,level(0));
  float4 y = b.sample(s,p.xyz,(i+1)&1,level(0));
  out[i]=x+y;
}
