#include <metal_stdlib>
using namespace metal;
kernel void cs(device uint2 *input [[buffer(0)]], device uint4 *output [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
 uint2 v=input[tid];
 output[tid]=uint4(simd_min(v.x),v.x,simd_max(v.y),v.y);
}
