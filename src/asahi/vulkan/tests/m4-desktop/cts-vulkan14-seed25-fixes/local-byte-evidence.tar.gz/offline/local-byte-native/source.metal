#include <metal_stdlib>
using namespace metal;
kernel void cs(device uchar *out [[buffer(0)]], device uint *indices [[buffer(1)]], uint tid [[thread_position_in_threadgroup]]) {
 threadgroup uchar values[128];
 values[indices[tid] & 127] = out[tid];
 threadgroup_barrier(mem_flags::mem_threadgroup);
 out[tid] = values[(indices[tid] + 1) & 127];
}
