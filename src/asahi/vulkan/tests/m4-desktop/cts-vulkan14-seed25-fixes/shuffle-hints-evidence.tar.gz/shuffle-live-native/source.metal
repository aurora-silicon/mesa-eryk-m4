#include <metal_stdlib>
using namespace metal;
kernel void cs(device uint4 *input [[buffer(0)]], device uint4 *output [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
 uint4 v=input[tid]; uint lane=(tid+5)&31;
 output[tid]=uint4(simd_shuffle(v.x,lane),simd_shuffle(v.y,lane),simd_shuffle(v.z,lane),simd_shuffle(v.w,lane));
}
