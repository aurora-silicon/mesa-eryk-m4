#include <metal_stdlib>
using namespace metal;
kernel void cs(texture3d<uint, access::read> tex [[texture(0)]], device uint4 *out [[buffer(0)]], device uint4 *coords [[buffer(1)]], uint tid [[thread_position_in_grid]]) {
 uint4 c = coords[tid];
 out[2*tid] = tex.read(c.xyz, 0);
 out[2*tid+1] = tex.read(c.xyz, c.w);
}
