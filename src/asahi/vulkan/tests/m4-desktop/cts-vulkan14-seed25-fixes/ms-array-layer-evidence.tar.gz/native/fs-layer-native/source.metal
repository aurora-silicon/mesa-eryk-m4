#include <metal_stdlib>
using namespace metal;
struct V { float4 p [[position]]; uint layer [[render_target_array_index]]; };
vertex V vs(uint id [[vertex_id]], constant uint &layer [[buffer(0)]]) {
float2 p[] = {float2(-1,-1),float2(3,-1),float2(-1,3)};
return {float4(p[id%3],0,1),layer};
}
fragment float4 fs(uint layer [[render_target_array_index]]) { return float4(float(layer),0,0,1); }
