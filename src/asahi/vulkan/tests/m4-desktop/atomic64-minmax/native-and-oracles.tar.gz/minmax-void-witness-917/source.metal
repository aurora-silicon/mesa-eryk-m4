#include <metal_stdlib>
using namespace metal;
kernel void cs(device atomic_ulong *value [[buffer(0)]], device const ulong *input [[buffer(1)]], uint i [[thread_position_in_grid]]) {
 atomic_min_explicit(value + i, input[2*i], memory_order_relaxed);
 atomic_max_explicit(value + i, input[2*i+1], memory_order_relaxed);
}
