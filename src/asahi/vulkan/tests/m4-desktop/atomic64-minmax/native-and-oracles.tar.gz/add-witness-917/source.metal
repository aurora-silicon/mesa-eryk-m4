#include <metal_stdlib>
using namespace metal;
kernel void cs(device atomic_ulong *value [[buffer(0)]], device ulong *output [[buffer(1)]], uint i [[thread_position_in_grid]]) {
 output[i] = atomic_fetch_add_explicit(value + i, ulong(7), memory_order_relaxed);
}
