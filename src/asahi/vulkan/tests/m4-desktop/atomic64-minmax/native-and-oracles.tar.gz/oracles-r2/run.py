import json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
failed=0
for name in json.loads((r/'cases.json').read_text()):
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run([sys.argv[2],str(r/(name+'.spv')),str(r/'input.bin'),str(r/(name+'.bin')),'4',str(out/(name+'.bin'))],env=dict(os.environ,M4_ORACLE_ATOMIC64='1'),stdout=log,stderr=subprocess.STDOUT,timeout=20)
 print(('PASS' if p.returncode==0 else 'FAIL')+': '+name,flush=True);failed+=p.returncode!=0
print(('FAIL' if failed else 'PASS')+': six unsigned atomic64 minmax configurations',flush=True)
sys.exit(bool(failed))
