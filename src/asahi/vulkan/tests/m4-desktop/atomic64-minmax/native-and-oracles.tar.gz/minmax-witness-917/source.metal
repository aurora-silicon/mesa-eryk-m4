#include <metal_stdlib>
using namespace metal;
kernel void cs(device atomic_ulong *value [[buffer(0)]], device ulong *output [[buffer(1)]], device const ulong *input [[buffer(2)]], uint i [[thread_position_in_grid]]) {
 output[2*i] = atomic_fetch_min_explicit(value + i, input[2*i], memory_order_relaxed);
 output[2*i+1] = atomic_fetch_max_explicit(value + i, input[2*i+1], memory_order_relaxed);
}
