#include <metal_stdlib>
using namespace metal;
#pragma METAL internals : enable
kernel void cs(device ulong *value [[buffer(0)]], device ulong *output [[buffer(1)]], device const ulong *input [[buffer(2)]], uint i [[thread_position_in_grid]]) {
 output[i] = __metal_atomic_fetch_add_explicit(value + i, input[i], 0, __METAL_MEMORY_SCOPE_DEVICE__, __METAL_MEMORY_FLAGS_NONE__);
}
#pragma METAL internals : disable
